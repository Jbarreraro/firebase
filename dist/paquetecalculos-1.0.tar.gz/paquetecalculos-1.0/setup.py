from setuptools import setup

setup(
    name = "paquetecalculos",
    version="1.0",
    description = "Paquete de redondeo y potencia",
    author= "Juan",
    author_email= "jbarrera0314@gmail.com",
    packages = ["calculos","calculos.operaciones_basicas"]

)