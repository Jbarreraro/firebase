def suma (a,b):
    print("Resultado: ",a+b)

def resta (a,b):
    print("Resultado: ",a-b)

def multiplicacion (a,b):
    print("Resultado: ",a*b)

def division (a,b):
    print("Resultado: ",a/b)